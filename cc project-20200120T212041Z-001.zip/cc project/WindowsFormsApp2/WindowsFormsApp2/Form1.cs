﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Text.RegularExpressions;

namespace WindowsFormsApp2

{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //dictionary initailliazation
        Dictionary<string, string> Keywordss = new Dictionary<string, string>()
        {
          {"Main" , "Main"} , {"void", "void"} ,{"MainClass" , "MainClass"} ,  {"int" , "DT"} , {"float", "DT"} , {"char", "DT"} , {"string","DT"} , {"bool","DT"} , {"Floop","Floop"} , {"Wloop","Wloop"} , {"Jump","Jump"} , {"Break","Break"}, {"Switch","Switch"} , {"Case","Case"}, {"Default","Default"} , {"Class","Class"} , {"public","AM"} , {"private","AM"} ,{"If","If"},{"Iff","Iff" },{"Else","Else"},{"return","return"},{"Sealed","Sealed"},{"Abstract","Abstract"},{"EndFloop","EndFloop"},{"EndWloop","EndWloop"} ,{"override","VO"},{"virtual","VO"},{"new","new"}
        };
        Dictionary<string, string> Opr = new Dictionary<string, string>()
        {
            {"+","PM" } , {"-","PM"} , {"*","MDM"} , {"/","MDM"} , {"%","MDM"} , {"=","="} , {"+=","Asgn_Op"} , {"-=","Asgn_Op"} , {"*=","Asgn_Op"} , {"/=","Asgn_Op"} , {"%=","Asgn_Op"} , {"++","INC_DEC"} , {"--","INC_DEC"} , {"&&","&&"} , {"||","||"} , {"<","ROP"} , {">","ROP"} , {"<<","SO"} , {">>","SO"} , {"==","ROP"} , {"!=","ROP"}, {"!","UNO"}, {"<=","ROP"} , {">=","ROP"}
        };
        Dictionary<string, string> Punct = new Dictionary<string, string>
        {
            { "." , "."} , {",",","} , {";",";"} , {"(","("} ,{")",")"} , {"{","{"} , {"}","}"} , {"[","["} , {"]","]"} , {"::","::"} , {":",":"}
        };

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public String input;
        public string temp = "";
        public string temp1 = "";
        public string temp2 = "";


        ArrayList token = new ArrayList();
        ArrayList token2 = new ArrayList();
        ArrayList naya_token = new ArrayList();
        public int lineno = 1;

        bool A1;
        bool A2;
        bool A3;
        bool A4;
        bool A5;


        Regex ID = new Regex("^[_a-zA-Z][a-zA-Z0-9_]{0,}$");
        // Regex ID = new Regex("^[_]{1}[A-Za-z0-9]+|[A-Za-z][A-Za-z0-9]*|[A-Za-z0-9]+[_]*[A-Za-z0-9]+$");
        Regex Int_Const = new Regex("^[-+][0-9]+$|^[0-9]+$|^[0-9][-+][0-9]$");
        Regex Float_Const = new Regex("^[+-][0-9]+[.][0-9]+$|^[0-9]*[.][0-9]+$");
        Regex Char_Const = new Regex(@"^'[a-zA-z0-9]'$|^'[+-]'$|^'\\[nrt]'$");
        Regex Str_Const = new Regex("^\"([a-zA-Z0-9]|(\\\\\\\\)|[!@#$%^&*()-=+{}|;:<>,.?/']|\\[|\\]|_|\\\\[nrtfab0]|\\\\\"|\\\\')*\"$");


        private void button1_Click(object sender, EventArgs e)
        {
        StartPosition:

            for (int x = 0; x < richTextBox1.Lines.Length; x++)
            {

                input = richTextBox1.Lines[x];

                for (int j = 0; j < richTextBox1.Lines[x].Length; j++)
                {

                Start_Pos:
                    if (j == input.Length)
                    {
                        break;
                    }
                    //float logic calling

                    if (input[j] == '.' && input[j + 1] == '1' ||
                      input[j] == '.' && input[j + 1] == '2' ||
                      input[j] == '.' && input[j + 1] == '3' ||
                      input[j] == '.' && input[j + 1] == '4' ||
                      input[j] == '.' && input[j + 1] == '5' ||
                      input[j] == '.' && input[j + 1] == '6' ||
                      input[j] == '.' && input[j + 1] == '7' ||
                      input[j] == '.' && input[j + 1] == '8' ||
                      input[j] == '.' && input[j + 1] == '9' ||
                     input[j] == '.' && input[j + 1] == '0')
                    {

                        goto float_Check;

                    }


                    //string start
                    if (input[j] == '"')
                    {
                        temp = Convert.ToString(input[j]);
                        j++;

                    here:
                        if (j == input.Length - 1)
                        {
                            temp = temp + input[j];
                            // token.Add(temp);
                            break;
                        }

                        if (input[j] == '\\')
                        {
                            if (j == input.Length - 1)
                            {
                                temp = temp + input[j];
                                token.Add(temp);
                                goto StartPosition;
                            }

                            temp = temp + input[j] + input[j + 1];
                            j += 2;
                            goto here;

                        }

                        if (input[j] != '"')
                        {
                            temp = temp + input[j];
                            j++;

                            goto here;
                        }

                        if (input[j] == '"')
                        {
                            temp = temp + input[j];
                            //token.Add(temp);
                            //temp = "";
                            j++;

                        }

                    } //striing end

                    /*  if(input[j]=='\'')
                      {
                          token.Add(temp);
                          temp = "";

                          temp = Convert.ToString(input[j]);
                          token.Add(temp);

                          temp = "";
                          j++;
                      }
                      */

                    //char start
                    if (j < input.Length - 3)
                    {
                        if (input[j] == '\'' && input[j + 1] == '\\' && input[j + 3] == '\'')

                        {
                            if (temp != "")
                            {
                                token.Add(temp);
                                temp = ("");
                            }


                            temp = Convert.ToString(input[j]) + Convert.ToString(input[j + 1]) + Convert.ToString(input[j + 2]) + Convert.ToString(input[j + 3]);
                            token.Add(temp);
                            temp = "";
                            j++;
                            j++;
                            j++;
                            j++;

                        }

                    }





                    if (j < input.Length - 2)
                    {

                        if (input[j] == '\'')

                        {
                            if (temp != "")
                            {
                                token.Add(temp);
                                temp = ("");
                            }


                            temp = Convert.ToString(input[j]) + Convert.ToString(input[j + 1]) + Convert.ToString(input[j + 2]);
                            token.Add(temp);
                            temp = "";
                            j++;
                            j++;
                            j++;

                        }

                    } //charend



                //if (j <= input.Length - 1)
                //{



                // .condition

                //float logic implementation
                float_Check:

                    if (input[j] == '.' && input[j + 1] == '1' ||
                   input[j] == '.' && input[j + 1] == '2' ||
                   input[j] == '.' && input[j + 1] == '3' ||
                   input[j] == '.' && input[j + 1] == '4' ||
                   input[j] == '.' && input[j + 1] == '5' ||
                   input[j] == '.' && input[j + 1] == '6' ||
                   input[j] == '.' && input[j + 1] == '7' ||
                   input[j] == '.' && input[j + 1] == '8' ||
                   input[j] == '.' && input[j + 1] == '9' ||
                   input[j] == '.' && input[j + 1] == '0')
                    {

                        if (temp == "")
                        {
                            goto dot_creat;
                        }

                        temp = "";

                    temp1_creat:
                        j--;

                        if (j == -1)
                        {
                            goto dot_enter;

                        }

                        else if (input[j] != '=' && input[j] != ' ' && input[j] != '\n' && input[j] != '.')

                        {
                            temp1 = input[j] + temp1;
                            goto temp1_creat;

                        }




                    dot_enter:
                        j++;
                    dot_creat:

                        if (input[j] != '.')
                        {
                            j++;
                            goto dot_creat;
                        }


                        temp = Convert.ToString(input[j]);


                    temp2_creat:

                        j++;
                        if (j == input.Length)
                        {
                            goto regex_passing;

                        }

                        if (input[j] != '=' && input[j] != ' ' && input[j] != '\n' && input[j] != '.')
                        {
                            temp2 = temp2 + input[j];
                            goto temp2_creat;
                        }

                    regex_passing:
                        bool result_temp1 = Int_Const.IsMatch(Convert.ToString(temp1));
                        bool result_temp2 = Int_Const.IsMatch(Convert.ToString(temp2));

                        if (result_temp1 == true && result_temp2 == true)
                        {
                            //  pre_tokens.Add(temp1 + temp + temp2);
                            token.Add(temp1 + temp + temp2);
                            temp = "";
                            temp1 = "";
                            temp2 = "";
                        }

                        if (result_temp1 == false && result_temp2 == true)
                        {

                            // pre_tokens.Add(temp1);
                            //pre_tokens.Add(temp + temp2);
                            token.Add(temp1);
                            token.Add(temp + temp2);
                            temp = "";
                            temp1 = "";
                            temp2 = "";
                        }

                        if (result_temp1 == false && result_temp2 == false)
                        {
                            //   pre_tokens.Add(temp1);
                            // pre_tokens.Add(temp);
                            //pre_tokens.Add(temp2);
                            token.Add(temp1);
                            token.Add(temp + temp2);
                            temp = "";
                            temp1 = "";
                            temp2 = "";
                        }

                        if (result_temp1 == true && result_temp2 == false)
                        {
                            //pre_tokens.Add(temp1);
                            //pre_tokens.Add(temp);
                            //pre_tokens.Add(temp2);
                            token.Add(temp1);
                            token.Add(temp + temp2);
                            temp = "";
                            temp1 = "";
                            temp2 = "";
                        }

                        goto Start_Pos;
                    }
                    // @comment  
                    if (input[j] == '@')
                    {

                        while (j <= input.Length - 1)
                        {

                            j++;

                        }
                        break;

                    }



                    //multi-line Comment
                    //if (input[j] == '/' && input[j + 1] == '*')
                    //{
                    //    token.Add(temp);
                    //    temp = null;
                    //    j += 2;
                    //db_Comment:
                    //    if (input[j] == '\n')
                    //    {
                    //        lineno++;
                    //    }
                    //    if (input[j] == '*' && input[j + 1] == '/')
                    //    {
                    //        j += 2;
                    //        if (j == input.Length)
                    //        {
                    //            break;
                    //        }
                    //        goto Start_Pos;
                    //    }

                    //    j++;
                    //    goto db_Comment;
                    //}







                    //wordbreakstart

                    if (input[j] == '+' ||
                        input[j] == '-' ||
                        input[j] == '*' ||
                        input[j] == '/' ||
                        input[j] == '%' ||
                        input[j] == '<' ||
                        input[j] == '>' ||
                        input[j] == ';' ||
                        input[j] == ',' ||
                        input[j] == ':' ||
                        input[j] == '{' ||
                        input[j] == '}' ||
                        input[j] == '(' ||
                        input[j] == ')' ||
                        input[j] == '[' ||
                        input[j] == ']' ||
                        input[j] == ' ' ||
                        input[j] == '&' ||
                        input[j] == '|' ||
                        input[j] == '!' ||
                        input[j] == '\'' ||
                        input[j] == '"' ||
                        input[j] == '.' ||
                        input[j] == '=')
                    {

                        if (input[j] == '+' && input[j + 1] == '=' ||
                           input[j] == '-' && input[j + 1] == '=' ||
                           input[j] == '*' && input[j + 1] == '=' ||
                           input[j] == '/' && input[j + 1] == '=' ||
                           input[j] == '%' && input[j + 1] == '=' ||
                           input[j] == '=' && input[j + 1] == '=' ||
                           input[j] == '>' && input[j + 1] == '=' ||
                           input[j] == '<' && input[j + 1] == '=' ||
                           input[j] == '!' && input[j + 1] == '=' ||
                           input[j] == '&' && input[j + 1] == '&' ||
                           input[j] == '|' && input[j + 1] == '|' ||
                           input[j] == '+' && input[j + 1] == '+' ||
                           input[j] == '-' && input[j + 1] == '-')
                        {
                            if (temp != "")
                            {
                                token.Add(temp);
                                temp = "";
                            }
                            temp = Convert.ToString(input[j]) + Convert.ToString(input[j + 1]);
                            token.Add(temp);
                            temp = "";
                            j++;

                            //goto here;
                        }

                        else

                        {

                            if (temp != "")
                            {
                                token.Add(temp);
                                temp = "";
                            }
                            temp = Convert.ToString(input[j]);
                            token.Add(temp);
                            temp = "";
                        }

                    }

                    // wordbreakend

                    else
                    {

                        temp = temp + input[j];
                    }
                    //  }


                }

                token.Add(temp);
                temp = "";

                token.Add("enter");

            }
            //print word break in richtextbox2
            foreach (string item in token)
            {
                richTextBox2.Text = richTextBox2.Text + item + '\n';
            }

            //alag token me space r enter k bghr
            for (int l = 0; l < token.Count; l++)
            {
                if (token[l] != " " && token[l] != "\n" && token[l] != "" && token[l] != "  "
                    && token[l] != "   " && token[l] != "    " && token[l] != "\r")
                {
                    naya_token.Add(token[l]);
                }
            }






            //token making
            //functions
            string is_Key(string a1)
            {
                string val = "";
                if (Keywordss.TryGetValue(a1, out val))
                {
                    return val;
                }
                else
                {
                    return "no match";
                }
            }
            string is_Opr(string a2)
            {
                string val = "";
                if (Opr.TryGetValue(a2, out val))
                {
                    return val;
                }
                else
                {
                    return "no match";
                }
            }
            string is_Punc(string a3)
            {
                string val = "";
                if (Punct.TryGetValue(a3, out val))
                {
                    return val;
                }
                else
                {
                    return "no match";
                }
            }

            for (int w = 0; w < naya_token.Count; w++)
            {
                string ent = Convert.ToString(naya_token[w]);
                if (ent == "enter")
                {
                    lineno++;
                    continue;
                }

                string space = Convert.ToString(naya_token[w]);
                if (space == " ")
                {

                    continue;
                }

                string kw = is_Key(Convert.ToString(naya_token[w]));
                if (kw != "no match")
                {
                    Token obj = new Token(kw, Convert.ToString(naya_token[w]), lineno);
                    token2.Add(obj);
                    kw = "";
                    continue;
                }

                string opr = is_Opr(Convert.ToString(naya_token[w]));
                if (opr != "no match")
                {
                    opr = is_Opr(Convert.ToString(naya_token[w]));
                    Token obj = new Token(opr, Convert.ToString(naya_token[w]), lineno);
                    token2.Add(obj);
                    opr = "";
                    continue;
                }

                string puncc = is_Punc(Convert.ToString(naya_token[w]));
                if (puncc != "no match")
                {
                    puncc = is_Punc(Convert.ToString(naya_token[w]));
                    Token obj = new Token(puncc, Convert.ToString(naya_token[w]), lineno);
                    token2.Add(obj);
                    puncc = "";
                    continue;
                }

                if (kw == "no match" && opr == "no match" && puncc == "no match")
                {

                    A1 = ID.IsMatch(Convert.ToString(naya_token[w]));
                    A2 = Int_Const.IsMatch(Convert.ToString(naya_token[w]));
                    A3 = Float_Const.IsMatch(Convert.ToString(naya_token[w]));
                    A4 = Char_Const.IsMatch(Convert.ToString(naya_token[w]));
                    A5 = Str_Const.IsMatch(Convert.ToString(naya_token[w]));

                }
                if (A1 == true)
                {
                    Token obj = new Token("ID", Convert.ToString(naya_token[w]), lineno);
                    token2.Add(obj);
                    A1 = false;
                    continue;
                }
                else if (A2 == true)
                {
                    Token obj = new Token("Int_Const", Convert.ToString(naya_token[w]), lineno);
                    token2.Add(obj);
                    A2 = false;
                    continue;
                }
                else if (A3 == true)
                {
                    Token obj = new Token("Flt_Const", Convert.ToString(naya_token[w]), lineno);
                    token2.Add(obj);

                    A3 = false;
                    continue;
                }
                else if (A4 == true)
                {
                    Token obj = new Token("Char_Const", Convert.ToString(naya_token[w]), lineno);
                    token2.Add(obj);
                    A4 = false;
                    continue;
                }
                else if (A5 == true)
                {
                    Token obj = new Token("Str_Const", Convert.ToString(naya_token[w]), lineno);
                    token2.Add(obj);
                    A5 = false;
                    continue;
                }
                //else
                //{
                //    token obj = new token("Invalid", Convert.ToString(mini_token[i]), line_No);
                //    tokenss.Add(obj);
                //    A6 = false;

                //}
                if (A1 == false && A2 == false && A3 == false && A4 == false && A5 == false)
                {
                    Token obj = new Token("Invalid", Convert.ToString(naya_token[w]), lineno);
                    token2.Add(obj);
                }
                A1 = false;
                A2 = false;
                A3 = false;
                A4 = false;
                A5 = false;

            }
            Token obj1 = new Token("$", "$", lineno);
            token2.Add(obj1);
            foreach (object s in token2)
            {
                richTextBox3.Text = richTextBox3.Text + '\n' + s.ToString();
            }
            //syntax analyzer

            token2[] TS;
            TS = new token2[token2.Count];
            for (int k = 0; k < token2.Count; k++)
            {
                string a1 = Convert.ToString(token2[k]);
                string[] parts = a1.Split('|');
                string Cp = parts[0].Substring(1).Trim();
                string Vp = parts[1].Trim();
                string LineNo = parts[2].Substring(0, parts[2].Length - 1);

                foreach (string xx in parts)
                {
                    TS[k] = new token2(Cp, Vp, LineNo);
                }

            }

            MessageBox.Show("Mapped All Tokens");
            for (int j = 0; j < TS.Length; j++)
            {
                richTextBox4.Text = richTextBox4.Text + TS[j].Get_CP() + TS[j].Get_VP() + TS[j].Get_Line();
            }
            //for(int i=0;i<TS.Length;i++)
            //{
            int i = 0;
            string CCC;
            CCC = TS[i].Get_CP();

            if (S1())
            {
                if (CCC == "$")
                {
                    MessageBox.Show("Valid Syntax");
                    richTextBox5.Text = "Valid Syntax";
                }


            }
            else if (S1() == false)
            {


                MessageBox.Show("Invalid Syntax");

                richTextBox5.Text = "Invalid Syntax" + " , " + "Error at Line" + TS[i].Get_Line();



            }



            bool S1()
            {
                if (Main())
                {
                    if (Classes())
                    {
                        return true;
                    }
                }
                return false;
            }

            bool Main()
            {
                if (CCC == "AM")
                {
                    i++;
                    CCC = TS[i].Get_CP(); //Class part updated


                    if (CCC == "Class")
                    {
                        i++;
                        CCC = TS[i].Get_CP();

                        if (CCC == "MainClass")
                        {
                            i++;
                            CCC = TS[i].Get_CP();

                            if (ClassBase())
                            {
                                if (CCC == "{")
                                {
                                    i++;
                                    CCC = TS[i].Get_CP();

                                    if (CBODY())
                                    {   
                                        
                                        if (CCC == "}")
                                        {
                                            i++;
                                            CCC = TS[i].Get_CP();
                                            return true;
                                        }

                                    }
                                }
                            }

                        }

                    }
                }
                return false;
            }
            bool ClassBase()
            {
                if (CCC == "::")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "ID")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        return true;
                    }
                }
                else if (CCC == "{")
                {
                    return true;
                }
                return false;
            }
            bool MF()
            {/////////////
                if (mainFunction())
                {
                    return true;
                }
                return false;
            }

            bool mainFunction()
            {
                if (CCC == "void")
                {
                    i++;
                    CCC = TS[i].Get_CP();

                    if (CCC == "Main")
                    {
                        i++;
                        CCC = TS[i].Get_CP();

                        if (CCC == "(")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (CCC == ")")
                            {
                                i++;
                                CCC = TS[i].Get_CP();
                                if (Body())
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
                return false;
            }
            bool Classes()
            {
                if (Class_Dec1())
                {
                    if (Classes())
                    {
                        return true;
                    }
                }
                else if (CCC == "$")
                {
                    return true;
                }
                return false;
            }
            bool Class_Dec1()
            {
                if (CCC == "AM")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (Class_Dec2())
                    {
                        return true;
                    }
                }
                return false;
            }
            bool Class_Dec2()
            {
                if (AAA())
                {
                    if (ClassDec())
                    {
                        return true;
                    }
                }
                else if (Abstr_st())
                {
                    return true;
                }
                return false;
            }

            bool ClassDec()
            {
                if (CCC == "Class")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "ID")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (ClassBase())
                        {
                            if (Body())
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            bool AAA()
            {
                if (CCC == "Sealed")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    return true;
                }
                else if (CCC == "Class")
                {
                    return true;
                }
                return false;
            }
            bool Abstr_st()
            {
                if (CCC == "Abstract")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "Class")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (CCC == "ID")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (ClassBase())
                            {
                                if (CCC == "{")
                                {
                                    i++;
                                    CCC = TS[i].Get_CP();
                                    if (Abs_Functions())
                                    {
                                        if (CCC == "}")
                                            i++;
                                        CCC = TS[i].Get_CP();
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
                return false;
            }
            bool Abs_Functions()
            {
                if (CCC == "AM")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (Abstr_AD())
                    {
                        if (Abs_N())
                        {
                            return true;
                        }
                    }
                    return false;
                }
                return false;
            }
            bool Abstr_AD()
            {
                if (CCC == "Abstract")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (ART())
                    {
                        if (CCC == "ID")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (CCC == "(")
                            {
                                i++;
                                CCC = TS[i].Get_CP();
                                if (Func_Cond())
                                {
                                    if (CCC == ")")
                                        i++;
                                    CCC = TS[i].Get_CP();
                                    if (CCC == ";")
                                    {
                                        i++;
                                        CCC = TS[i].Get_CP();
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
                return false;
            }
            bool Abs_N()
            {
                if (CCC == "AM")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (functions())
                    {
                        if (Abs_N())
                        {
                            return true;
                        }
                    }
                }
                else if (CCC == "}")
                {
                    return true;
                }
                return false;
            }
            bool functions()
            {
                if (Abstr_AD())
                {
                    return true;
                }
                else if (Func_st())
                {
                    return true;
                }
                return false;
            }

            bool ART()
            {
                if (CCC == "DT" || CCC == "void")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    return true;
                }
                return false;
            }

            bool Arr_Dec_E()
            {
                if (CCC == "[")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (E())
                    {
                        if (CCC == "]")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (CCC == "=")
                            {
                                i++;
                                CCC = TS[i].Get_CP();
                                if (E())
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
                return false;
            }

            bool Body()
            {
                if (CCC == "{")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (MST())
                    {
                        if (CCC == "}")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            return true;
                        }

                    }
                }
                return false;
            }

            bool MST()
            {

                if (SST())
                {
                    if (MST())
                    {
                        return true;
                    }
                }

                else if (CCC == "}" || CCC == "AM" || CCC == "Break")
                {
                    return true;
                }

                return false;
            }
            bool SST()
            {
                if (If_st())
                {
                    return true;
                }
                else if (Iff_st())
                {
                    return true;
                }
                else if (Floop_st())
                {
                    return true;
                }
                else if (Wlloop_st())
                {
                    return true;
                }
                else if (Break_st())
                {
                    return true;
                }
                else if (Jump_st())
                {
                    return true;
                }
                else if (Ret_st())
                {
                    return true;
                }
                else if (sw_st())
                {
                    return true;
                }
                else if (LocalDec())
                {
                    return true;
                }
                else if (CCC == "ID")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (SST_2())
                    {
                        if (CCC == ";")
                            i++;
                        CCC = TS[i].Get_CP();
                        return true;
                    }
                }
                else if (CCC == "AM")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (RT1())
                    {
                        return true;
                    }
                }
                return false;
            }
            bool If_st()
            {
                if (CCC == "If")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "(")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (Exp())
                        {
                            if (CCC == ")")
                            {
                                i++;
                                CCC = TS[i].Get_CP();
                                if (Body())
                                {
                                    if (Else_st())
                                    {
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
                return false;
            }
            bool Else_st()
            {
                if (CCC == "Else")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (Body())
                    {
                        return true;
                    }
                }
                return false;
            }
            bool Iff_st()
            {
                if (CCC == "Iff")
                {
                    i++;
                    CCC = TS[i].Get_CP();

                    if (CCC == "(")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (Exp())
                        {
                            if (CCC == ")")
                            {
                                i++;
                                CCC = TS[i].Get_CP();
                                if (Body())
                                {
                                    return true;
                                }
                            }
                        }
                    }

                }
                return false;
            }
            bool Jump_st()
            {
                if (CCC == "Jump")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "ID")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (CCC == ";")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            return true;
                        }
                    }
                }
                return false;
            }
            bool Break_st()
            {
                if (CCC == "Break")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == ";")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        return true;
                    }
                }
                return false;

            }

            bool sw_st()///////////////////
            {
                if (CCC == "Switch")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "(")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (CCC == "ID")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (CCC == ")")
                            {
                                i++;
                                CCC = TS[i].Get_CP();
                                if (CCC == "{")
                                {
                                    i++;
                                    CCC = TS[i].Get_CP();
                                    if (Case())
                                    {
                                        if (Default())
                                        {
                                            if (CCC == "}")
                                                i++;
                                            CCC = TS[i].Get_CP();
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                return false;
            }
            bool Case()
            {
                if (CCC == "Case")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (Case_2())
                    {
                        if (CCC == ":")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (Body())
                            {
                                if (CCC == "Break")
                                {
                                    i++;
                                    CCC = TS[i].Get_CP();
                                    if (CCC == ";")
                                    {
                                        i++;
                                        CCC = TS[i].Get_CP();
                                        if (Case())
                                        {
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else if (CCC == "Default")
                {
                    return true;
                }

                return false;
            }
            bool Case_2()
            {
                if (CCC == "Int_Const" || CCC == "Char_Const")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    return true;
                }
                return false;
            }

            bool Default()
            {
                if (CCC == "Default")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == ":")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (DFB())
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            bool DFB()
            {
                if (CCC == "Break")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == ";")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        return true;
                    }
                }
                else if (MST())
                {
                    if (CCC == "Break")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (CCC == ";")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            return true;
                        }
                    }
                }
                return false;
            }
            bool LIST()
            {
                if (CCC == ";")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    return true;
                }
                else if (CCC == ",")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "DT")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (CCC == "ID")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (INIT())
                            {
                                if (LIST())
                                {
                                    return true;
                                }
                            }

                        }
                    }
                }
                return false;
            }
            bool INIT()
            {
                if (CCC == "=")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (Exp())
                    {
                        return true;
                    }
                }
                else if (CCC == "," || CCC == ";")
                {
                    return true;
                }
                return false;
            }
            bool DecINIT()
            {
                if (CCC == "," || CCC == ";" || CCC == "=")
                {
                    if (INIT())
                    {
                        if (LIST())
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            bool Dec()
            {
                if (CCC == "AM")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "DT")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (CCC == "ID")
                        {
                            if (DecINIT())
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            bool Wlloop_st()
            {
                if (CCC == "Wloop")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == ":")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (CCC == "[")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (Exp())
                            {
                                if (CCC == "]")
                                {
                                    i++;
                                    CCC = TS[i].Get_CP();

                                    if (Body())
                                    {
                                        if (CCC == "EndWloop")
                                        {
                                            i++;
                                            CCC = TS[i].Get_CP();
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
                return false;
            }
            bool Floop_st()
            {
                if (CCC == "Floop")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == ":")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (CCC == "[")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (C1())
                            {
                                if (C2())
                                {
                                    if (CCC == ";")
                                    {
                                        i++;
                                        CCC = TS[i].Get_CP();
                                        if (C3())
                                        {
                                            if (CCC == "]")
                                            {
                                                i++;
                                                CCC = TS[i].Get_CP();
                                                if (Body())
                                                {
                                                    if (CCC == "EndFloop")
                                                    {
                                                        i++;
                                                        CCC = TS[i].Get_CP();
                                                        return true;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                return false;
            }
            bool C1()
            {
                if (LocalDec())
                {
                    return true;
                }
                else if (Asgn())
                {
                    if (CCC == ";")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        return true;
                    }

                }
                else if (CCC == ";")
                {
                    return true;
                }
                return false;
            }
            bool C2()
            {
                if (Exp())
                {
                    return true;
                }
                else if (CCC == ";")
                {
                    return true;
                }
                return false;
            }
            bool C3()
            {
                if (CCC == "ID")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (C33())
                    {
                        return true;
                    }
                }
                else if (CCC == "INC_DEC")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "ID")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        return true;
                    }
                }
                else if (CCC == "]")
                {
                    return true;
                }
                return false;
            }
            bool C33()
            {
                if (AS1())
                {
                    return true;
                }
                else if (CCC == "INC_DEC")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    return true;
                }
                return false;
            }
            bool Asgn()
            {
                if (CCC == "ID")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (AS1())
                    {
                        return true;
                    }
                }
                return false;
            }
            bool AS1()
            {
                if (Asgn_Op())
                {
                    if (Exp())
                    {
                        return true;
                    }
                }
                return false;
            }
            bool Asgn_Op()
            {
                if (CCC == "=" || CCC == "Asgn_Op")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    return true;

                }
                return false;
            }
            bool Ret_st()
            {
                if (CCC == "return")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (Exp())
                    {
                        if (CCC == ";")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            return true;
                        }

                    }
                }
                return false;
            }

            bool Constr_Call1()
            {
                if (CCC == "ID")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (Call1_Constr())
                    {
                        return true;
                    }

                }
                return false;
            }
            bool Call1_Constr()
            {
                if (CCC == "=")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "new")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (CCC == "ID")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (CCC == "(")
                            {
                                i++;
                                CCC = TS[i].Get_CP();
                                if (Exp())
                                {
                                    if (CCC == ")")
                                    {
                                        i++;
                                        CCC = TS[i].Get_CP();
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
                else if (CCC == ";")
                {
                    return true;
                }
                return false;
            }
            bool APL()
            {
                if (CCC == "Int_Const" || CCC == "ID")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    return true;
                }
                else if (CCC == "]")
                {
                    return true;
                }
                return false;
            }
            bool DecArrWala()
            {
                if (CCC == "[")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (APL())
                    {
                        if (CCC == "]")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (DecArrWala2())
                            {
                                return true;
                            }
                        }
                    }
                }

                return false;
            }
            bool DecArrWala2()
            {
                if (CCC == "[")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (APL())
                    {
                        if (CCC == "]")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            return true;
                        }
                    }
                }
                else if (CCC == ";" || CCC == "{" || CCC == "=")
                {
                    return true;
                }

                return false;
            }

            bool INIT_Arr()
            {
                if (CCC == ";")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    return true;
                }
                else if (CCC == "=")
                {

                    i++;
                    CCC = TS[i].Get_CP();

                    if (CCC == "{")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (NewArray())
                        {
                            return true;
                        }
                    }
                }

                return false;
            }

            bool Arr_C()
            {
                if (Const())
                {
                    if (Arr_C2())
                    {
                        if (CCC == "}")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (CCC == ";")
                            {
                                i++;
                                CCC = TS[i].Get_CP();
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            bool Arr_C2()
            {
                if (CCC == ",")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (Const())
                    {
                        if (Arr_C2())
                        {
                            return true;
                        }

                    }
                }
                else if (CCC == "}")
                {
                    return true;
                }
                return false;
            }
            bool Arr_C3()
            {
                if (CCC == "{")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (Const())
                    {
                        if (CCC == ",")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (Const())
                            {
                                if (CCC == "}")
                                {
                                    i++;
                                    CCC = TS[i].Get_CP();
                                    if (Arr_C4())
                                    {
                                        if (CCC == "}")
                                        {
                                            i++;
                                            CCC = TS[i].Get_CP();
                                            if (CCC == ";")
                                            {
                                                i++;
                                                CCC = TS[i].Get_CP();
                                                return true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                return false;
            }
            bool Arr_C4()
            {
                if (CCC == ",")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (Arr_C3())
                    {
                        return true;
                    }
                }
                else if (CCC == "}")
                {
                    return true;
                }
                return false;
            }
            bool NewArray()
            {
                if (CCC == "Int_Const" || CCC == "Flt_Const" || CCC == "Char_Const" || CCC == "Str_Const" || CCC == "Bool_Const")
                {
                    if (Arr_C())
                    {
                        return true;
                    }
                }
                else if (CCC == "{")
                {
                    if (Arr_C3())
                    {
                        return true;
                    }
                }
                return false;
            }

            bool Const()
            {
                if (CCC == "Int_Const" || CCC == "Flt_Const" || CCC == "Char_Const" || CCC == "Str_Const" || CCC == "Bool_Const")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    return true;
                }
                return false;
            }

            bool X()
            {
                if (CCC == ",")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (E())
                    {
                        if (X())
                        {
                            return true;
                        }
                    }
                }
                else if (CCC == "[")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (E())
                    {
                        if (CCC == "]")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (X())
                            {
                                return true;
                            }
                        }
                    }
                }
                else if (CCC == ")")
                {
                    return true;
                }
                return false;
            }

            bool FunctCall()
            {
                if (E())
                {
                    if (X())
                    {
                        return true;
                    }
                }
                return false;
            }

            bool Func_Call_Cond()
            {
                if (FunctCall())
                {
                    return true;
                }
                else if (CCC == ")")
                {
                    return true;
                }
                return false;
            }

            bool N_Func()
            {
                if (CCC == "(")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (Func_Call_Cond())
                    {
                        if (CCC == ")")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            return true;
                        }
                    }
                }
                else if (ObjC())
                {
                    return true;
                }
                return false;
            }
            bool ObjC()
            {
                if (CCC == ".")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "ID")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (A44())
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            bool A44()
            {
                if (CCC == "[")
                {

                    i++;
                    CCC = TS[i].Get_CP();
                    if (E())
                    {
                        if (CCC == "]")
                        {
                            i++;
                            CCC = TS[i].Get_CP();

                            if (A44())
                            {
                                return true;
                            }
                        }
                    }
                }
                else if (CCC == "(")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (Func_Call_Cond())
                    {
                        if (CCC == ")")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (A44())
                            {
                                return true;
                            }
                        }
                    }
                }
                else if (CCC == ".")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "ID")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (A44())
                        {
                            return true;
                        }
                    }
                }
                else if (CCC == "INC_DEC")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (A44())
                    {
                        return true;
                    }
                }
                else if (CCC == ";")
                {
                    return true;
                }
                return false;
            }
            bool VO()
            {
                if (CCC == "virtual" || CCC == "override")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    return true;
                }
                else if (CCC == "(")
                {
                    return true;
                }
                return false;
            }
            bool Return_Type()
            {
                if (CCC == "DT" || CCC == "void")
                {
                    i++;
                    CCC = TS[i].Get_CP();

                    return true;
                }
                else if (CCC == "ID")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "ID")
                    {
                        return true;

                    }
                    if (VO())
                    {
                        return true;
                    }
                }
                return false;
            }
            bool Func_st()
            {
                if (Return_Type())
                {
                    if (CCC == "ID")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (VO())
                        {
                            if (DecFuncCond())
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }

            bool DecFuncCond()
            {
                if (CCC == "(")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (Func_Cond())
                    {
                        if (CCC == ")")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (Body())
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            bool FC2()
            {
                if (CCC == "[")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "]")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (FCB2())
                        {
                            return true;
                        }
                    }
                }
                else if (CCC == "," || CCC == ")")
                {
                    return true;
                }
                return false;
            }
            bool FCB2()
            {
                if (CCC == "[")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "]")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        return true;
                    }
                }
                else if (CCC == "," || CCC == ")")
                {
                    return true;
                }
                return false;
            }
            bool Func_Cond2()
            {
                if (CCC == ",")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "DT")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (CCC == "ID")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (FC2())
                            {
                                if (Func_Cond2())
                                {
                                    return true;
                                }
                            }
                        }
                    }

                }
                else if (CCC == ")")
                {
                    return true;
                }
                return false;
            }

            bool Func_Cond()
            {
                if (CCC == "DT")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "ID")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (FC2())
                        {
                            if (Func_Cond2())
                            {
                                return true;
                            }
                        }
                    }
                }
                else if (CCC == ")")
                {
                    return true;
                }
                return false;
            }

            bool SST_2()
            {
                if (N_Func())
                {
                    return true;
                }
                else if (AS1())
                {
                    return true;
                }
                else if (CCC == "INC_DEC")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    return true;
                }
                else if (Constr_Call1())
                {
                    return true;
                }
                else if (Arr_Dec_E())
                {
                    return true;
                }
                return false;
            }

            bool RT1()
            {
                if (CCC == "DT")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (ArrayHoSakta())
                    {
                        if (CCC == "ID")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if (RT2())
                            {
                                return true;
                            }
                        }
                    }
                }
                else if (CCC == "ID")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (RT3())
                    {
                        return true;
                    }
                }
                else if (CCC == "void")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "ID")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (VO())
                        {
                            if (DecFuncCond())
                            {
                                return true;
                            }
                        }
                    }
                }
               
                return false;
            }

            bool RT2()
            {

                if (DecArrWala())
                {
                    if (INIT_Arr())
                    {
                        return true;
                    }
                }
                else if (DecINIT())
                {
                    return true;
                }
                else if (VO())
                {

                    if (DecFuncCond())
                    {
                        return true;
                    }
                }
                return false;
            }

            bool RT3()
            {
                if (DecFuncCond())
                {
                    return true;
                }
                else if (CCC == "ID")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (VO())
                    {
                        if (DecFuncCond())
                        {
                            return true;
                        }
                    }
                }
                return false;
            }



            bool Exp()
            {
                if (O())
                {
                    return true;
                }
                return false;
            }

            bool O()
            {
                if (A())
                {
                    if (O_Dash())
                    {
                        return true;
                    }
                }
                return false;
            }
            bool O_Dash()
            {
                if (CCC == "||")
                {
                    if (A())
                    {
                        if (O_Dash())
                        {
                            return true;
                        }
                    }
                }
                else if (CCC == "," || CCC == ";" || CCC == ")" || CCC == "]")
                {
                    return true;
                }
                return false;
            }
            bool A()
            {
                if (R())
                {
                    if (A_Dash())
                    {
                        return true;
                    }
                }
                return false;
            }
            bool A_Dash()
            {
                if (CCC == "&&")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (R())
                    {
                        if (A_Dash())
                        {
                            return true;
                        }
                    }
                }
                else if (CCC == "||" ||
                         CCC == "," || CCC == ";" || CCC == ")" || CCC == "]")
                {
                    return true;
                }

                return false;
            }
            bool R()
            {
                if (E())
                {
                    if (R_Dash())
                    {
                        return true;
                    }
                }
                return false;
            }
            bool R_Dash()
            {
                if (CCC == "ROP")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (E())
                    {
                        if (R_Dash())
                        {
                            return true;
                        }
                    }
                }
                else if (CCC == "&&" || CCC == "||" ||
                         CCC == "," || CCC == ";" || CCC == ")" || CCC == "]")
                {
                    return true;
                }
                return false;
            }
            bool E()
            {
                if (T())
                {
                    if (E_Dash())
                    {
                        return true;
                    }
                }
                return false;
            }
            bool E_Dash()
            {
                if (CCC == "PM")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (T())
                    {
                        if (E_Dash())
                        {
                            return true;
                        }
                    }
                }
                else if (CCC == "ROP" || CCC == "&&" || CCC == "||" ||
                         CCC == "," || CCC == ";" || CCC == ")" || CCC == "]")
                {
                    return true;
                }
                return false;
            }
            bool T()
            {
                if (F())
                {
                    if (T_Dash())
                    {
                        return true;
                    }
                }
                return false;
            }
            bool T_Dash()
            {
                if (CCC == "MDM")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (F())
                    {
                        if (T_Dash())
                        {
                            return true;
                        }
                    }
                }
                else if (CCC == "PM" || CCC == "ROP" || CCC == "&&" ||
                    CCC == "||" || CCC == "," || CCC == ";" || CCC == ")" || CCC == "]")
                {
                    return true;
                }
                return false;
            }
            bool F()
            {
                if (Const())
                {
                    return true;
                }
                else if (CCC == "(")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (O())
                    {
                        if (CCC == ")")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            return true;
                        }
                    }
                }
                else if (CCC == "!")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (F())
                    {
                        return true;
                    }
                }
                else if (CCC == "INC_DEC")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "ID")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (CCC == ";")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            return true;
                        }
                    }
                }
                else if (CCC == "ID")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (F_Dash())
                    {
                        return true;
                    }
                }
                return false;
            }

            bool F_Dash()
            {
                if (SST_2())
                {
                    if (CCC == ";")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        return true;

                    }
                }
                else if (CCC == "MDM" || CCC == "PM" ||
                   CCC == "ROP" || CCC == "&&" || CCC == "||" ||
                   CCC == "," || CCC == ";" || CCC == ")" || CCC == "]")
                {
                    return true;
                }
                return false;
            }
            bool ArrayHoSakta()
            {
                if (CCC == "[")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "]")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        return true;
                    }

                }
                else if (CCC == "If" || CCC == "Iff" || CCC == "Floop"
                || CCC == "Wloop" || CCC == "Switch" || CCC == "Break"
                || CCC == "Jump" || CCC == "return" || CCC == "ID" || CCC == "AM")
                {
                    return true;
                }
                return false;
            }

            bool LocalDec()
            {
                if (CCC == "DT")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (CCC == "ID")
                    {
                        i++;
                        CCC = TS[i].Get_CP();
                        if (DecINIT())
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            bool CBODY()
            {
                if(CBODYAttr())
                {
                    if(mainFunction())
                    {
                        if(CBODYAttr())
                        {
                            return true;
                        }
                    }
                }
               
                return false;
            }
            bool CBODYAttr()
            {
                if (CCC == "ID")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (Constr_Call1())
                    {
                        if (CCC == ";")
                        {
                            i++;
                            CCC = TS[i].Get_CP();
                            if(CBODYAttr())
                            {
                                return true;
                            }
                        }
                    }
                }
                else if (CCC == "AM")
                {
                    i++;
                    CCC = TS[i].Get_CP();
                    if (RT1())
                    {
                        if(CBODYAttr())
                        {
                            return true;
                        }
                    }
                }
                else if(CCC == "void" || CCC == "}")
                {
                    return true;
                }
                return false;
            }



            // }


        }

    }




    class Token
    {
        string classPart;
        string valuePart;
        int lineno;



        public Token(string cp, string vp, int line)
        {
            classPart = cp;
            valuePart = vp;
            lineno = line;
        }

        public override string ToString()
        {
            return "(" + classPart  +' ' + '|' + ' ' + valuePart + ' ' + '|' + ' ' + lineno + ")";
        }


    }
    public class token2
    {
        string class_part;
        string value_part;
        string line_no;




        public token2(string cp, string vp, string ln)
        {
            class_part = cp;
            value_part = vp;
            line_no = ln;
        }

        public override string ToString()
        {
            return "(" + class_part + ' ' + '|' + ' ' +  value_part + ' ' + '|' + ' '  + line_no + ")";
        }

        public string Get_CP()
        {
            return class_part;
        }
        public string Get_VP()
        {
            return value_part;
        }
        public string Get_Line()
        {
            return line_no;
        }
    }

}












